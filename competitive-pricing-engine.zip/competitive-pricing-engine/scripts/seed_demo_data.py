"""Generate realistic synthetic data so the whole pipeline runs without scraping live sites.
Usage: python scripts/seed_demo_data.py
"""
import os
import sys
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from pricing_engine.config import OUR_STORE  # noqa: E402
from pricing_engine.db import get_engine, init_db, metadata  # noqa: E402

rng = np.random.default_rng(42)
DAYS = 60
CITIES = {"Delhi": (28.61, 77.21), "Mumbai": (19.08, 72.88), "Bengaluru": (12.97, 77.59),
          "Lucknow": (26.85, 80.95), "Chennai": (13.08, 80.27), "Kolkata": (22.57, 88.36)}
PRODUCTS = [("P001", "Wireless Earbuds", "Audio", 1200), ("P002", "Bluetooth Speaker", "Audio", 1500),
            ("P003", "Smartwatch", "Wearables", 2500), ("P004", "Fitness Band", "Wearables", 900),
            ("P005", "Power Bank 20000mAh", "Accessories", 800), ("P006", "Fast Charger 65W", "Accessories", 600)]
COMPETITORS = {  # name: (price factor, rating, review weight, currency)
    OUR_STORE: (1.00, 4.2, 0.8, "INR"), "AmazonLike": (0.97, 4.3, 3.0, "INR"), "FlipLike": (0.99, 4.1, 2.2, "INR"),
    "BazaarHub": (0.93, 3.8, 1.0, "INR"), "NicheShop": (1.15, 4.6, 0.3, "INR")}


def main():
    init_db()
    eng = get_engine()
    with eng.begin() as con:
        con.execute(metadata.tables["price_observations"].delete())
        con.execute(metadata.tables["products"].delete())

    start = datetime.now().replace(hour=9, minute=0, second=0, microsecond=0) - timedelta(days=DAYS)
    obs, prod_rows = [], []
    for pid, name, cat, cost in PRODUCTS:
        base = cost * rng.uniform(1.5, 1.9)
        prod_rows.append({"product_id": pid, "name": name, "category": cat, "cost": cost, "our_price": round(base, 2)})
        for comp, (f, rating, w, cur) in COMPETITORS.items():
            price, reviews = base * f, int(rng.integers(500, 5000) * w)
            for d in range(DAYS):
                price = float(np.clip(price * (1 + rng.normal(0, 0.012)), cost * 1.1, base * 1.6))
                if rng.random() < 0.05:                      # occasional promotion / competitor price move
                    price *= rng.uniform(0.88, 0.95)
                reviews += rng.poisson(max(1, 8 * w * (price / base) ** -1.5))
                units = int(rng.choice([1, 1, 1, 2]))
                list_price = price * rng.uniform(1.1, 1.3)
                if comp == "NicheShop":                      # inflated "was" prices -> fake discounts
                    list_price = price * rng.uniform(1.5, 1.9)
                city, (lat, lon) = list(CITIES.items())[int(rng.integers(0, len(CITIES)))]
                obs.append({"product_id": pid, "competitor": comp, "observed_at": start + timedelta(days=d),
                            "list_price": round(list_price * units, 2), "sale_price": round(price * units, 2),
                            "currency": cur, "units_in_pack": units,
                            "shipping_cost": 0.0 if price > 999 else 49.0,
                            "loyalty_discount_pct": float(rng.choice([0, 0, 5, 10])),
                            "rating": None if rng.random() < 0.03 else round(float(np.clip(rating + rng.normal(0, 0.05), 1, 5)), 2),
                            "review_count": reviews, "region": city, "lat": lat, "lon": lon, "source_url": f"https://demo.local/{comp}/{pid}"})
    pd.DataFrame(prod_rows).to_sql("products", eng, if_exists="append", index=False)
    pd.DataFrame(obs).to_sql("price_observations", eng, if_exists="append", index=False)
    print(f"Seeded {len(prod_rows)} products and {len(obs)} observations.")


if __name__ == "__main__":
    main()
