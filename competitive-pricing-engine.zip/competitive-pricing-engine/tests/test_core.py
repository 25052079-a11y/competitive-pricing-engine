import pandas as pd

from pricing_engine.cleaning.normalize import flag_fake_discounts, normalize_prices
from pricing_engine.engine.rules import Constraints, recommend_price
from pricing_engine.engine.simulator import ab_test_sample_size, simulate


def test_normalize_per_unit_and_currency():
    df = pd.DataFrame([{"product_id": "A", "competitor": "X", "observed_at": pd.Timestamp("2026-01-01"), "list_price": 20,
                        "sale_price": 10, "currency": "USD", "units_in_pack": 2, "shipping_cost": 0, "loyalty_discount_pct": 0}])
    out = normalize_prices(df)
    assert out["sale_per_unit_inr"].iloc[0] == 10 * 83 / 2


def test_fake_discount_flagged():
    rows = [{"product_id": "A", "competitor": "X", "observed_at": pd.Timestamp("2026-01-0%d" % i), "list_price": 100,
             "sale_price": 100, "currency": "INR", "units_in_pack": 1, "shipping_cost": 0, "loyalty_discount_pct": 0}
            for i in range(1, 6)]
    rows.append({**rows[0], "observed_at": pd.Timestamp("2026-01-09"), "list_price": 200, "sale_price": 100})
    out = flag_fake_discounts(normalize_prices(pd.DataFrame(rows)))
    assert out["fake_discount"].sum() == 1


def test_margin_floor_enforced():
    r = recommend_price(100, 95, [50, 55, 60], "aggressive", Constraints(min_margin_pct=15, max_change_pct=50))
    assert r["recommended_price"] >= 95 * 1.15


def test_change_cap():
    r = recommend_price(100, 10, [50, 55, 60], "aggressive", Constraints(max_change_pct=10))
    assert r["recommended_price"] >= 90


def test_simulate_elastic_price_cut_raises_demand():
    s = simulate(100, 90, 50, 100, -2.0)
    assert s["demand"] > 100


def test_sample_size_positive():
    assert ab_test_sample_size(0.05, 0.1) > 1000
