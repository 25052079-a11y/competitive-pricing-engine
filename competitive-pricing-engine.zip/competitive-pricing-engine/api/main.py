"""FastAPI service. Run: uvicorn api.main:app --reload"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from pricing_engine import service
from pricing_engine.engine.rules import STRATEGIES, Constraints
from pricing_engine.engine.simulator import simulate

app = FastAPI(title="Competitive Intelligence & Pricing API", version="1.0.0")


class SimRequest(BaseModel):
    our_price: float = Field(gt=0)
    new_price: float = Field(gt=0)
    cost: float = Field(ge=0)
    base_demand: float = Field(gt=0)
    elasticity: float = -1.2


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/recommendations")
def recommendations(strategy: str = "balanced", min_margin_pct: float = 15.0, max_change_pct: float = 10.0):
    if strategy not in STRATEGIES:
        raise HTTPException(400, f"strategy must be one of {list(STRATEGIES)}")
    df = service.recommendations(strategy, Constraints(min_margin_pct, max_change_pct))
    return df.to_dict(orient="records")


@app.get("/alerts")
def alerts(threshold_pct: float = 5.0):
    return service.alerts(threshold_pct).astype({"observed_at": str}).to_dict(orient="records")


@app.get("/quality")
def quality():
    return service.scorecard().to_dict(orient="records")


@app.post("/simulate")
def simulate_price(req: SimRequest):
    return simulate(req.our_price, req.new_price, req.cost, req.base_demand, req.elasticity)
