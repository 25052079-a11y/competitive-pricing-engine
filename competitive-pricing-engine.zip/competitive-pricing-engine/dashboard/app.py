"""Streamlit Command Center. Run: streamlit run dashboard/app.py"""
import os
import sys

import folium
import plotly.express as px
import streamlit as st
from streamlit_folium import st_folium

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from pricing_engine import service  # noqa: E402
from pricing_engine.analysis import positioning as pos  # noqa: E402
from pricing_engine.config import OUR_STORE  # noqa: E402
from pricing_engine.engine.rules import STRATEGIES, Constraints  # noqa: E402
from pricing_engine.engine.simulator import ab_test_sample_size  # noqa: E402

st.set_page_config(page_title="Pricing Command Center", layout="wide")
st.title("Competitive Intelligence & Pricing Command Center")


@st.cache_data(ttl=300)
def data():
    return service.load_clean(), service.load_products()


try:
    df, products = data()
except Exception:
    st.error("No data found. Run `python scripts/seed_demo_data.py` first.")
    st.stop()

with st.sidebar:
    st.header("Controls")
    strategy = st.selectbox("Strategy", list(STRATEGIES), index=1)
    margin = st.slider("Minimum margin %", 0, 50, 15)
    max_chg = st.slider("Max price change per cycle %", 1, 30, 10)
    alert_thr = st.slider("Alert threshold %", 1, 20, 5)

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
    ["Overview", "Positioning", "Recommendations", "Scenario simulator", "Alerts & geo", "Data quality"])

with tab1:
    snap = pos.latest_snapshot(df)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Products", len(products))
    c2.metric("Competitors tracked", df["competitor"].nunique() - 1)
    c3.metric("Observations", f"{len(df):,}")
    c4.metric("Suspected fake discounts", f"{df['fake_discount'].mean():.1%}")
    pid = st.selectbox("Product", products["product_id"], format_func=lambda x: products.set_index("product_id").loc[x, "name"])
    fig = px.line(df[df["product_id"] == pid], x="observed_at", y="effective_per_unit_inr", color="competitor",
                  title="Effective price per unit (INR)")
    st.plotly_chart(fig, use_container_width=True)

with tab2:
    seg = pos.segment_competitors(df)
    st.plotly_chart(px.scatter(seg, x="avg_rating", y="avg_price", size="reviews", color="segment", text="competitor",
                               title="Perceptual map: price vs quality"), use_container_width=True)
    st.subheader("Pricing gaps vs market")
    st.dataframe(pos.price_gaps(df, products[["product_id", "name", "our_price"]]).round(2), use_container_width=True)
    st.subheader("Elasticity proxy (directional)")
    st.dataframe(pos.elasticity_proxy(df).round(3), use_container_width=True)

with tab3:
    recs = service.recommendations(strategy, Constraints(margin, max_chg))
    st.dataframe(recs.drop(columns=["reasons"]).assign(reasons=recs["reasons"].apply("; ".join)), use_container_width=True)
    st.download_button("Download CSV", recs.drop(columns=["reasons"]).to_csv(index=False), "recommendations.csv")
    st.subheader("A/B test planner")
    a, b = st.columns(2)
    base_cr = a.number_input("Baseline conversion rate", 0.001, 0.9, 0.05, 0.005)
    lift = b.number_input("Minimum detectable relative lift", 0.01, 1.0, 0.10, 0.01)
    st.info(f"~{ab_test_sample_size(base_cr, lift):,} visitors per arm needed.")

with tab4:
    pid2 = st.selectbox("Simulate product", products["product_id"], key="sim")
    base_demand = st.number_input("Baseline units / period", 1, 100000, 100)
    sim = service.scenario_table(pid2, base_demand)
    st.dataframe(sim, use_container_width=True)
    st.plotly_chart(px.bar(sim, x="strategy", y="profit", title="Projected profit by strategy"), use_container_width=True)

with tab5:
    al = service.alerts(alert_thr)
    st.subheader("Competitor alerts")
    st.dataframe(al, use_container_width=True) if len(al) else st.success("No alerts at this threshold.")
    st.subheader("Average competitor price index by region")
    g = (df[df["competitor"] != OUR_STORE].groupby(["region", "lat", "lon"])["effective_per_unit_inr"].mean().reset_index())
    m = folium.Map(location=[22.5, 79], zoom_start=5)
    for _, r in g.iterrows():
        folium.CircleMarker([r.lat, r.lon], radius=8 + r.effective_per_unit_inr / g.effective_per_unit_inr.max() * 12,
                            popup=f"{r.region}: INR {r.effective_per_unit_inr:,.0f}", fill=True).add_to(m)
    st_folium(m, height=450, width=None)

with tab6:
    st.dataframe(service.scorecard(), use_container_width=True)
    st.subheader("Suspected fake discounts by competitor")
    st.dataframe(df.groupby("competitor")["fake_discount"].mean().rename("share").reset_index().round(3))
