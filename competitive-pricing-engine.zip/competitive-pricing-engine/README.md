# Competitive Intelligence & Pricing Strategy Engine for E-Commerce

End-to-end platform that tracks competitor prices, cleans and normalizes them, analyses market positioning,
recommends prices under business constraints, and presents everything in a Streamlit command center.

## Architecture
```
scrapers -> PostgreSQL/SQLite -> cleaning/normalization -> analysis -> rule engine -> FastAPI + Streamlit
```

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python scripts/seed_demo_data.py          # synthetic data, no scraping needed
streamlit run dashboard/app.py            # dashboard on :8501
uvicorn api.main:app --reload             # API docs on :8000/docs
pytest                                    # run tests
```

## Docker / Kubernetes
```bash
docker compose up --build                 # local stack with PostgreSQL
docker build -t pricing-engine:latest .
kubectl apply -f k8s/                     # Postgres, API, dashboard, scraper CronJob
```
Edit `k8s/postgres.yaml` to change the placeholder password before deploying.

## Project layout
```
pricing_engine/   scrapers, cleaning, analysis, engine (rules, simulator), service layer
api/              FastAPI endpoints (/recommendations, /alerts, /quality, /simulate)
dashboard/        Streamlit app
scripts/          demo data seeding
config/           competitor scraping config
k8s/              Kubernetes manifests
docs/             framework, weekly plan, playbook
tests/            pytest suite
```

## Features
- Ethical scraping (robots.txt, rate limits, config-driven selectors, Playwright fallback)
- Price normalization across currency and pack size; effective price including shipping and loyalty discounts
- Fake-discount detection and data-quality scorecards
- Perceptual map, price gaps, elasticity proxy, leader/challenger/niche segmentation
- Aggressive / balanced / conservative pricing with margin floor and change caps
- Scenario simulator, competitor alerts, geo map, A/B sample-size planner

## Notes
Demo data is synthetic. Only scrape sites whose Terms of Service allow it. FX rates in `config.py` are static placeholders.
