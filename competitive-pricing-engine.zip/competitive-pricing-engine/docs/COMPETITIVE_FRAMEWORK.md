# Competitive Intelligence Framework (Weeks 1-2 template)

Fill this in with your chosen categories and real competitors.

## 1. Scope
- Product categories: (e.g. Audio, Wearables, Accessories)
- Market segments: (budget / mid-range / premium)
- Geography: (regions or cities)

## 2. Competitor map
| Competitor | Tier | Typical price index (market median = 100) | Discount style | Bundles/loyalty | Positioning |
|-----------|------|-----|------|------|------|
|  |  |  |  |  |  |

## 3. Metrics tracked
Sale price, list price, discount %, shipping, loyalty offers, pack size, rating, review count, region.

## 4. Data collection ethics
Respect robots.txt and each site's Terms of Service, rate-limit requests, identify the bot, store only public product data.

## 5. Questions the platform should answer
- Where are we priced above or below market?
- Which competitors use inflated "was" prices?
- How price-sensitive is each product?
- What price maximizes profit within our margin rules?
