# Weekly Plan and Where Each Deliverable Lives

| Week | Focus | Code / docs |
|------|-------|-------------|
| 1-2 | Competitive landscape mapping | `docs/COMPETITIVE_FRAMEWORK.md`, `config/competitors.yaml` |
| 3 | Ethical scraping infrastructure | `pricing_engine/scrapers/`, `pricing_engine/db.py` |
| 4 | Cleaning and normalization | `pricing_engine/cleaning/normalize.py` |
| 5-6 | Positioning analysis | `pricing_engine/analysis/positioning.py` |
| 6 | Recommendation engine | `pricing_engine/engine/rules.py`, `simulator.py` (A/B sizing) |
| 7 | Streamlit command center | `dashboard/app.py` |
| 7-8 | Dynamic pricing rule engine | `pricing_engine/engine/`, `api/main.py` |
| 8 | Kubernetes, PPT, handover | `Dockerfile`, `k8s/`, `docs/` |
