# Pricing Playbook (handover draft)

1. **Daily:** check Alerts tab; review competitor drops of 5% or more.
2. **Weekly:** review Recommendations under all three strategies; compare projected profit in the simulator.
3. **Before changing prices:** apply margin floor and change cap; run an A/B test (planner in dashboard) for high-revenue SKUs.
4. **Monthly:** re-check data quality scorecard and fake-discount rates; retune thresholds and FX rates.

Limitations: the elasticity proxy uses review growth as a stand-in for sales, so treat results as directional.
