"""Database schema (SQLAlchemy Core) - works on SQLite and PostgreSQL."""
from sqlalchemy import (Column, DateTime, Float, Integer, MetaData, String, Table,
                        create_engine)

from .config import DATABASE_URL

metadata = MetaData()

products = Table(
    "products", metadata,
    Column("product_id", String(50), primary_key=True),
    Column("name", String(200), nullable=False),
    Column("category", String(100)),
    Column("cost", Float, nullable=False),        # unit cost (INR)
    Column("our_price", Float, nullable=False),   # current selling price per unit (INR)
)

price_observations = Table(
    "price_observations", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("product_id", String(50), nullable=False, index=True),
    Column("competitor", String(100), nullable=False, index=True),
    Column("observed_at", DateTime, nullable=False, index=True),
    Column("list_price", Float),                  # "was"/MRP price shown
    Column("sale_price", Float, nullable=False),  # price actually charged
    Column("currency", String(3), default="INR"),
    Column("units_in_pack", Integer, default=1),
    Column("shipping_cost", Float, default=0.0),
    Column("loyalty_discount_pct", Float, default=0.0),
    Column("rating", Float),
    Column("review_count", Integer),
    Column("region", String(100)),
    Column("lat", Float),
    Column("lon", Float),
    Column("source_url", String(500)),
)

_engine = None


def get_engine():
    global _engine
    if _engine is None:
        _engine = create_engine(DATABASE_URL, future=True)
    return _engine


def init_db():
    metadata.create_all(get_engine())
