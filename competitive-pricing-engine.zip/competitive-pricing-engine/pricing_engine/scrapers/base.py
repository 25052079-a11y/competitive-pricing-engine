"""Ethical scraping base: robots.txt, rate limiting, identifiable User-Agent."""
import time
from datetime import datetime, timezone
from urllib import robotparser
from urllib.parse import urlparse

import requests

from ..config import SCRAPER_DELAY, USER_AGENT


class PoliteFetcher:
    def __init__(self, delay: float = SCRAPER_DELAY, user_agent: str = USER_AGENT):
        self.delay = delay
        self.headers = {"User-Agent": user_agent}
        self._robots: dict[str, robotparser.RobotFileParser] = {}
        self._last_request = 0.0

    def allowed(self, url: str) -> bool:
        p = urlparse(url)
        base = f"{p.scheme}://{p.netloc}"
        if base not in self._robots:
            rp = robotparser.RobotFileParser()
            rp.set_url(f"{base}/robots.txt")
            try:
                rp.read()
            except Exception:
                return False  # be conservative if robots.txt can't be read
            self._robots[base] = rp
        return self._robots[base].can_fetch(self.headers["User-Agent"], url)

    def get(self, url: str) -> str | None:
        if not self.allowed(url):
            print(f"[skip] robots.txt disallows {url}")
            return None
        wait = self.delay - (time.time() - self._last_request)
        if wait > 0:
            time.sleep(wait)
        resp = requests.get(url, headers=self.headers, timeout=20)
        self._last_request = time.time()
        resp.raise_for_status()
        return resp.text


def now_utc() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)
