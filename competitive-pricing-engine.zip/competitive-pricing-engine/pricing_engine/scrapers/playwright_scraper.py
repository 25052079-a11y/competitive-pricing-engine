"""Fallback for JavaScript-rendered pages. Requires: playwright install chromium"""
from playwright.sync_api import sync_playwright

from ..config import USER_AGENT
from .price_scraper import parse_page


def scrape_rendered(url: str, selectors: dict, wait_for: str | None = None) -> dict:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(user_agent=USER_AGENT)
        page.goto(url, timeout=30000)
        if wait_for:
            page.wait_for_selector(wait_for, timeout=15000)
        html = page.content()
        browser.close()
    return parse_page(html, selectors)
