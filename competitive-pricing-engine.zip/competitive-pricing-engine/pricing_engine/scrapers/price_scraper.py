"""Config-driven price/review scraper using requests + BeautifulSoup.

Targets and CSS selectors live in config/competitors.yaml, so adding a competitor
needs no code change. Only scrape sites whose Terms of Service permit it.
For JS-heavy pages see playwright_scraper.py.
"""
import re

import pandas as pd
import yaml
from bs4 import BeautifulSoup

from ..db import get_engine, init_db
from .base import PoliteFetcher, now_utc


def parse_number(text: str | None) -> float | None:
    if not text:
        return None
    m = re.search(r"[\d,]+(?:\.\d+)?", text)
    return float(m.group().replace(",", "")) if m else None


def parse_page(html: str, sel: dict) -> dict:
    soup = BeautifulSoup(html, "lxml")

    def pick(key):
        node = soup.select_one(sel[key]) if sel.get(key) else None
        return node.get_text(strip=True) if node else None

    return {
        "sale_price": parse_number(pick("sale_price")),
        "list_price": parse_number(pick("list_price")),
        "shipping_cost": parse_number(pick("shipping")) or 0.0,
        "rating": parse_number(pick("rating")),
        "review_count": parse_number(pick("review_count")),
    }


def run(config_path: str = "config/competitors.yaml") -> int:
    with open(config_path) as f:
        cfg = yaml.safe_load(f)
    fetcher, rows = PoliteFetcher(), []
    for comp in cfg["competitors"]:
        for target in comp["targets"]:
            html = fetcher.get(target["url"])
            if not html:
                continue
            rec = parse_page(html, comp["selectors"])
            if rec["sale_price"] is None:
                continue
            rows.append({**rec, "product_id": target["product_id"], "competitor": comp["name"],
                         "currency": comp.get("currency", "INR"), "units_in_pack": target.get("units_in_pack", 1),
                         "observed_at": now_utc(), "source_url": target["url"]})
    if rows:
        init_db()
        pd.DataFrame(rows).to_sql("price_observations", get_engine(), if_exists="append", index=False)
    return len(rows)


if __name__ == "__main__":
    print(f"Stored {run()} observations")
