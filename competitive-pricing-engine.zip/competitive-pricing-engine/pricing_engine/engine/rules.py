"""Weeks 6-8: pricing rules, strategies, constraints, alerts."""
from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class Strategy:
    name: str
    anchor: str          # "min" or "median" of competitor effective prices
    adjust_pct: float    # applied to anchor (negative = undercut)


STRATEGIES = {
    "aggressive": Strategy("aggressive", "min", -2.0),
    "balanced": Strategy("balanced", "median", -1.0),
    "conservative": Strategy("conservative", "median", +2.0),
}


@dataclass(frozen=True)
class Constraints:
    min_margin_pct: float = 15.0      # never price below cost * (1 + margin)
    max_change_pct: float = 10.0      # cap move per cycle
    max_price_vs_median_pct: float = 25.0


def recommend_price(our_price: float, cost: float, comp_prices: list[float],
                    strategy: str = "balanced", c: Constraints = Constraints()) -> dict:
    if not comp_prices:
        return {"recommended_price": our_price, "action": "hold", "change_pct": 0.0,
                "margin_pct": round((our_price - cost) / our_price * 100, 2), "reasons": ["no competitor data"]}
    s = STRATEGIES[strategy]
    prices = pd.Series(comp_prices)
    anchor = prices.min() if s.anchor == "min" else prices.median()
    target = anchor * (1 + s.adjust_pct / 100)
    reasons = [f"{s.name}: anchor={s.anchor} {anchor:.2f} ({s.adjust_pct:+.0f}%)"]

    ceiling = prices.median() * (1 + c.max_price_vs_median_pct / 100)
    if target > ceiling:
        target = ceiling
        reasons.append("market ceiling applied")

    lo, hi = our_price * (1 - c.max_change_pct / 100), our_price * (1 + c.max_change_pct / 100)
    if not lo <= target <= hi:
        reasons.append(f"capped to +/-{c.max_change_pct:.0f}% change")
    price = min(max(target, lo), hi)

    floor = cost * (1 + c.min_margin_pct / 100)   # margin floor always wins
    if price < floor:
        price = floor
        reasons.append(f"margin floor applied (>= {c.min_margin_pct:.0f}%)")

    price = round(price, 2)
    change = (price / our_price - 1) * 100
    action = "hold" if abs(change) < 0.5 else ("decrease" if change < 0 else "increase")
    return {"recommended_price": price, "action": action, "change_pct": round(change, 2),
            "margin_pct": round((price - cost) / price * 100, 2), "reasons": reasons}


def competitor_alerts(df: pd.DataFrame, drop_threshold_pct: float = 5.0) -> pd.DataFrame:
    """Alert when a competitor's latest effective price moved >= threshold vs its previous observation."""
    out = []
    for (pid, comp), g in df.sort_values("observed_at").groupby(["product_id", "competitor"]):
        if len(g) < 2:
            continue
        prev, last = g["effective_per_unit_inr"].iloc[-2], g["effective_per_unit_inr"].iloc[-1]
        chg = (last / prev - 1) * 100
        if abs(chg) >= drop_threshold_pct:
            out.append({"product_id": pid, "competitor": comp, "previous": round(prev, 2), "current": round(last, 2),
                        "change_pct": round(chg, 2), "type": "price_drop" if chg < 0 else "price_hike",
                        "observed_at": g["observed_at"].iloc[-1]})
    return pd.DataFrame(out, columns=["product_id", "competitor", "previous", "current", "change_pct", "type", "observed_at"])
