"""Pricing scenario simulation using constant-elasticity demand."""
import pandas as pd


def simulate(our_price: float, new_price: float, cost: float, base_demand: float, elasticity: float) -> dict:
    demand = base_demand * (new_price / our_price) ** elasticity
    rev, profit = demand * new_price, demand * (new_price - cost)
    base_rev, base_profit = base_demand * our_price, base_demand * (our_price - cost)
    return {"new_price": round(new_price, 2), "demand": round(demand, 1), "revenue": round(rev, 2),
            "profit": round(profit, 2), "revenue_delta_pct": round((rev / base_rev - 1) * 100, 2),
            "profit_delta_pct": round((profit / base_profit - 1) * 100, 2) if base_profit else None}


def compare_strategies(our_price, cost, base_demand, elasticity, recommended: dict) -> pd.DataFrame:
    rows = [{"strategy": name, **simulate(our_price, p, cost, base_demand, elasticity)} for name, p in recommended.items()]
    return pd.DataFrame(rows)


def ab_test_sample_size(baseline_rate: float, min_detectable_lift: float, alpha_z: float = 1.96, power_z: float = 0.84) -> int:
    """Per-arm sample size to detect a relative lift in conversion rate (two-sided, 80% power)."""
    p1, p2 = baseline_rate, baseline_rate * (1 + min_detectable_lift)
    pbar = (p1 + p2) / 2
    n = 2 * pbar * (1 - pbar) * ((alpha_z + power_z) / (p2 - p1)) ** 2
    return int(n) + 1
