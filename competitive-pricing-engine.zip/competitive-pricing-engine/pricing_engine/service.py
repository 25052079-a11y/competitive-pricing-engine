"""Shared service layer used by the API and the dashboard."""
import pandas as pd

from .analysis import positioning as pos
from .cleaning.normalize import flag_fake_discounts, normalize_prices, quality_scorecard
from .config import OUR_STORE
from .db import get_engine
from .engine.rules import STRATEGIES, Constraints, competitor_alerts, recommend_price
from .engine.simulator import compare_strategies


def load_clean() -> pd.DataFrame:
    df = pd.read_sql("select * from price_observations", get_engine(), parse_dates=["observed_at"])
    return flag_fake_discounts(normalize_prices(df))


def load_products() -> pd.DataFrame:
    return pd.read_sql("select * from products", get_engine())


def scorecard() -> pd.DataFrame:
    return quality_scorecard(pd.read_sql("select * from price_observations", get_engine(), parse_dates=["observed_at"]))


def recommendations(strategy: str = "balanced", constraints: Constraints = Constraints()) -> pd.DataFrame:
    df, products = load_clean(), load_products()
    snap = pos.latest_snapshot(df[df["competitor"] != OUR_STORE])
    rows = []
    for _, p in products.iterrows():
        comp = snap.loc[snap["product_id"] == p["product_id"], "effective_per_unit_inr"].tolist()
        rec = recommend_price(p["our_price"], p["cost"], comp, strategy, constraints)
        rows.append({"product_id": p["product_id"], "name": p["name"], "category": p["category"],
                     "current_price": p["our_price"], **rec})
    return pd.DataFrame(rows)


def scenario_table(product_id: str, base_demand: float = 100.0) -> pd.DataFrame:
    df, products = load_clean(), load_products()
    p = products[products["product_id"] == product_id].iloc[0]
    el = pos.elasticity_proxy(df).set_index("product_id").loc[product_id, "elasticity"]
    prices = {s: recommendations(s).set_index("product_id").loc[product_id, "recommended_price"] for s in STRATEGIES}
    out = compare_strategies(p["our_price"], p["cost"], base_demand, el, prices)
    out["elasticity_used"] = round(el, 2)
    return out


def alerts(threshold: float = 5.0) -> pd.DataFrame:
    return competitor_alerts(load_clean(), threshold)
