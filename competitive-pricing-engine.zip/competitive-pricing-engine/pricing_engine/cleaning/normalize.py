"""Week 4: price normalization, effective pricing, fake-discount detection, quality scorecard."""
import pandas as pd

from ..config import FX_TO_INR


def normalize_prices(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    fx = d["currency"].map(FX_TO_INR).fillna(1.0)
    packs = d["units_in_pack"].fillna(1).clip(lower=1)
    d["sale_inr"] = d["sale_price"] * fx
    d["list_inr"] = d["list_price"].fillna(d["sale_price"]) * fx
    d["shipping_inr"] = d["shipping_cost"].fillna(0) * fx
    d["sale_per_unit_inr"] = d["sale_inr"] / packs
    d["discount_pct"] = ((d["list_inr"] - d["sale_inr"]) / d["list_inr"] * 100).clip(lower=0)
    # Effective price = sale price after loyalty discount, plus shipping, per unit
    after_loyalty = d["sale_inr"] * (1 - d["loyalty_discount_pct"].fillna(0) / 100)
    d["effective_per_unit_inr"] = (after_loyalty + d["shipping_inr"]) / packs
    return d


def flag_fake_discounts(df: pd.DataFrame, threshold: float = 1.25, min_discount: float = 10) -> pd.DataFrame:
    """A discount is suspicious when the advertised 'was' price is far above any price
    the competitor actually charged for that product (median of its sale prices)."""
    d = df.copy()
    typical = d.groupby(["product_id", "competitor"])["sale_per_unit_inr"].transform("median")
    list_per_unit = d["list_inr"] / d["units_in_pack"].fillna(1).clip(lower=1)
    d["fake_discount"] = (list_per_unit > threshold * typical) & (d["discount_pct"] >= min_discount)
    return d


def quality_scorecard(df: pd.DataFrame, stale_days: int = 3) -> pd.DataFrame:
    """Per-competitor data quality: completeness, validity, duplicates, freshness (0-100)."""
    rows = []
    now = df["observed_at"].max()
    for comp, g in df.groupby("competitor"):
        completeness = 1 - g[["list_price", "rating", "review_count", "region"]].isna().mean().mean()
        validity = (g["sale_price"] > 0).mean()
        dup_rate = g.duplicated(["product_id", "observed_at"]).mean()
        fresh = float((now - g["observed_at"].max()).days <= stale_days)
        score = 100 * (0.4 * completeness + 0.3 * validity + 0.2 * (1 - dup_rate) + 0.1 * fresh)
        rows.append({"competitor": comp, "rows": len(g), "completeness": round(completeness, 3),
                     "validity": round(validity, 3), "duplicate_rate": round(dup_rate, 3),
                     "fresh": bool(fresh), "quality_score": round(score, 1)})
    return pd.DataFrame(rows).sort_values("quality_score", ascending=False)
