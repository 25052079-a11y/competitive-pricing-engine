"""Weeks 5-6: perceptual map, price gaps, elasticity proxy, competitor segmentation."""
import numpy as np
import pandas as pd

from ..config import OUR_STORE


def latest_snapshot(df: pd.DataFrame) -> pd.DataFrame:
    idx = df.groupby(["product_id", "competitor"])["observed_at"].idxmax()
    return df.loc[idx].reset_index(drop=True)


def perceptual_map(df: pd.DataFrame) -> pd.DataFrame:
    """Competitor-level price vs quality (rating) with review volume as bubble size."""
    snap = latest_snapshot(df)
    return (snap.groupby("competitor")
            .agg(avg_price=("effective_per_unit_inr", "mean"), avg_rating=("rating", "mean"),
                 reviews=("review_count", "sum"))
            .reset_index())


def price_gaps(df: pd.DataFrame, our_prices: pd.DataFrame) -> pd.DataFrame:
    """Gap (%) between our price and the market median/min per product."""
    snap = latest_snapshot(df[df["competitor"] != OUR_STORE])
    mkt = snap.groupby("product_id")["effective_per_unit_inr"].agg(market_min="min", market_median="median").reset_index()
    out = our_prices.merge(mkt, on="product_id")
    out["gap_vs_median_pct"] = (out["our_price"] / out["market_median"] - 1) * 100
    out["gap_vs_min_pct"] = (out["our_price"] / out["market_min"] - 1) * 100
    return out


def segment_competitors(df: pd.DataFrame) -> pd.DataFrame:
    """Leaders = top review share; niche = low share; the rest are challengers."""
    pm = perceptual_map(df)
    pm["review_share"] = pm["reviews"] / pm["reviews"].sum()
    hi, lo = pm["review_share"].quantile(0.75), pm["review_share"].quantile(0.35)
    pm["segment"] = np.where(pm["review_share"] >= hi, "Leader",
                             np.where(pm["review_share"] <= lo, "Niche", "Challenger"))
    return pm


def elasticity_proxy(df: pd.DataFrame, default: float = -1.2) -> pd.DataFrame:
    """log(daily demand proxy) ~ log(price) via OLS. Demand proxy = daily growth in review count
    (a rough stand-in for sales). Treat results as directional, not causal."""
    import statsmodels.api as sm

    rows = []
    for pid, g in df.groupby("product_id"):
        g = g.sort_values("observed_at").copy()
        g["demand"] = g.groupby("competitor")["review_count"].diff()
        g = g.dropna(subset=["demand"])
        g = g[(g["demand"] >= 0) & (g["sale_per_unit_inr"] > 0)]
        if len(g) < 20:
            rows.append({"product_id": pid, "elasticity": default, "r2": np.nan, "n": len(g), "fallback": True})
            continue
        x = sm.add_constant(np.log(g["sale_per_unit_inr"]))
        res = sm.OLS(np.log1p(g["demand"]), x).fit()
        e = float(res.params.iloc[1])
        ok = bool(np.isfinite(e) and e < 0)  # a positive slope is not economically sensible here
        rows.append({"product_id": pid, "elasticity": e if ok else default, "r2": float(res.rsquared),
                     "n": len(g), "fallback": not ok})
    return pd.DataFrame(rows)
