import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///data/pricing.db")
USER_AGENT = os.getenv("SCRAPER_USER_AGENT", "CompetitiveIntelBot/1.0 (+contact: you@example.com)")
SCRAPER_DELAY = float(os.getenv("SCRAPER_DELAY_SECONDS", "3"))

# Static demo FX rates to INR. Replace with a live/historical FX source in production.
FX_TO_INR = {"INR": 1.0, "USD": 83.0, "EUR": 90.0, "GBP": 105.0}

OUR_STORE = "OurStore"
